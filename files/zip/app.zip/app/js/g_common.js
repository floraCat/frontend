define(["jq"],function(){console.log("共用的脚本")});
define(["jq"],function(){console.log("头部的脚本")});